
from fastapi import FastAPI
from pydantic import BaseModel
import pickle
import numpy as np

app = FastAPI(title="AI Learning Intelligence Tool")

model = pickle.load(open("model/completion_model.pkl", "rb"))
scaler = pickle.load(open("model/scaler.pkl", "rb"))

class StudentData(BaseModel):
    student_id: str
    course_id: str
    chapter_order: int
    time_spent: int
    score: int

@app.post("/predict")
def predict(data: StudentData):
    X = scaler.transform([[data.chapter_order, data.time_spent, data.score]])
    prob = model.predict_proba(X)[0][1]
    prediction = "Likely to Complete" if prob >= 0.5 else "High Dropout Risk"

    insights = []
    if data.score < 50:
        insights.append("Low assessment score detected")
    if data.time_spent < 30:
        insights.append("Low engagement time")
    if data.chapter_order >= 4:
        insights.append("Later chapters show higher difficulty")

    return {
        "student_id": data.student_id,
        "prediction": prediction,
        "risk_score": round(prob, 2),
        "insights": insights
    }
